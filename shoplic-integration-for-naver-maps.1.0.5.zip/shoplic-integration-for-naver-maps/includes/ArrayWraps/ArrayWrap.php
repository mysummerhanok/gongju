<?php

namespace Shoplic\NaverMap\ArrayWraps;

interface ArrayWrap
{
}
