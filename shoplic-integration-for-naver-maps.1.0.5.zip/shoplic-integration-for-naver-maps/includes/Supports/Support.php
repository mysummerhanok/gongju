<?php

namespace Shoplic\NaverMap\Supports;

interface Support
{
}
