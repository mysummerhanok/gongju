<?php

namespace Shoplic\NaverMap\Modules;

interface Module
{
}
