<?php

namespace Shoplic\NaverMap\Modules;

use Exception;

class ModuleException extends Exception
{
}
