<?php
// Silence is gold.
